from django.apps import AppConfig


class AirportConfig(AppConfig):
    name = 'airport'
